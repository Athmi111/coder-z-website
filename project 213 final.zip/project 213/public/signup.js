// public/register.js
document
    .getElementById("registerForm")
    .addEventListener("submit", async (event) => {
        event.preventDefault();
        const password = document.getElementById("password").value;
        const fullName = document.getElementById("fullName").value;
        const phoneNumber = document.getElementById("phoneNumber").value;
        const collegeName = document.getElementById("collegeName").value;
        const sem = document.getElementById("sem").value;
        const response = await fetch("http://localhost:3000/update-details", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({password,fullName, phoneNumber,collegeName,sem }),
        });

        const data = await response.json();
        const messageElement = document.getElementById("message");

        if (response.ok) {
            window.location.href = 'index.html';
        }
        else {
            messageElement.textContent = data.message;
        }
    });
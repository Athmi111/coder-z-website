const express = require("express");
const session = require("express-session");
const cors = require("cors");
const bodyParser = require("body-parser");
const { MongoClient } = require("mongodb");

const app = express();
const port = 3000;
const mongoUrl = "mongodb://localhost:27017";
const dbName = "coderz";
const collectionName = "users";

app.use(cors());
app.use(bodyParser.json());
app.use(
    session({
        secret: "your_secret_key", // Secret used to sign the session ID cookie
        resave: false, // Whether to save the session even if it hasn't been modified
        saveUninitialized: false, // Whether to save new but uninitialized sessions
    })
);
async function connectToMongoDB() {
    const client = new MongoClient(mongoUrl);
    await client.connect();
    return client;
}
app.post("/login", async (req, res) => {
    const { username, password } = req.body;

    try {
        const client = await connectToMongoDB();
        const db = client.db(dbName);
        const users = db.collection(collectionName);

        const user = await users.findOne({ username, password });


        if (user) {
            req.session.username = username;
            res.status(200).json({ message: "Login successful" });
        } else {
            res.status(401).json({ message: "Invalid username or password" });
        }
        client.close();
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ message: "Internal Server Error" });
    }
});
// Registration endpoint for basic registration (username and email)
app.post("/register", async (req, res) => {
    const { username, email } = req.body;

    try {
        const client = await connectToMongoDB();
        const db = client.db(dbName);
        const users = db.collection(collectionName);

        // Check if the username or email already exists
        const existingUser = await users.findOne({ $or: [{ username }, { email }] });

        if (existingUser) {
            res.status(400).json({ message: "Username or email already exists" });
            return;
        }

        // Insert the new user with basic details into the database
        const newUser = { username, email };
        await users.insertOne(newUser);
        req.session.username = username;
        res.status(201).json({ message: "Registration successful" });

        client.close();
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ message: "Internal Server Error" });
    }
});

// Endpoint for updating user details
app.post("/update-details", async (req, res) => {
    const username = req.session.username;
    const {password, fullName, phoneNumber,collegeName,sem } = req.body;

    try {
        const client = await connectToMongoDB();
        const db = client.db(dbName);
        const users = db.collection(collectionName);
        // Check if the user exists
        const existingUser = await users.findOne({username});

        if (!existingUser) {
            res.status(404).json({ message: "User not found" });
            return;
        }

        // Update the user with additional details
        const updatedUser = { $set: {password,fullName, phoneNumber,collegeName,sem } };
        await users.updateOne({ username }, updatedUser);

        res.status(200).json({ message: "User details updated successfully" });

        client.close();
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ message: "Internal Server Error" });
    }
});
// Endpoint for retrieving user details
app.get("/user-details", async (req, res) => {
    const username = req.session.username;
console.log("username",username)
    if (!username) {
        // Handle the case where the cookie is not set
        res.status(401).send("Unauthorized");
        return;
    }

    try {
        const client = await connectToMongoDB();
        const db = client.db(dbName);
        const users = db.collection(collectionName);

        // Find the user by username
        const user = await users.findOne({ username });

        if (!user) {
            res.status(404).json({ message: "User not found" });
            return;
        }

        // Return user details
        res.status(200).json(user);

        client.close();
    } catch (error) {
        console.error("Error:", error);
        res.status(500).json({ message: "Internal Server Error" });
    }
});
app.use(express.static("public"));
app.listen(port, () => {
    console.log(`Server is listening on port ${port}`);
});